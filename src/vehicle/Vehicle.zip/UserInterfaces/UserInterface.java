/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle.UserInterfaces;

/**
 *
 * @author RXD0512A
 */
public interface UserInterface {
    void start();
}
